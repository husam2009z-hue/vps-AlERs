import json
import pickle
import time
import logging
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.FileHandler('/tmp/selenium.log'), logging.StreamHandler()],
)
log = logging.getLogger('job')

COOKIE_FILE = Path('/home/runner/work/cookies.pkl')
STATE_DIR = Path('/home/runner/work/state')
STATE_DIR.mkdir(parents=True, exist_ok=True)


def build_driver():
    o = Options()
    o.add_argument('--headless=new')
    o.add_argument('--no-sandbox')
    o.add_argument('--disable-dev-shm-usage')
    o.add_argument('--disable-gpu')
    o.add_argument('--window-size=1920,1080')
    o.add_argument('--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
    o.add_experimental_option('excludeSwitches', ['enable-automation'])
    o.add_experimental_option('useAutomationExtension', False)
    return webdriver.Chrome(options=o)


def load_cookies(d):
    if not COOKIE_FILE.exists():
        return
    try:
        with COOKIE_FILE.open('rb') as f:
            for c in pickle.load(f):
                try:
                    d.add_cookie(c)
                except Exception:
                    pass
        log.info('cookies loaded')
    except Exception as e:
        log.warning('cookie load: %s' % e)


def save_cookies(d):
    try:
        with COOKIE_FILE.open('wb') as f:
            pickle.dump(d.get_cookies(), f)
        log.info('cookies saved')
    except Exception as e:
        log.warning('cookie save: %s' % e)


def main():
    log.info('boot')
    d = build_driver()
    try:
        d.get('https://example.com')
        load_cookies(d)
        d.refresh()
        log.info('title: %s' % d.title)
        (STATE_DIR / 'last_state.json').write_text(
            json.dumps({'title': d.title, 'url': d.current_url, 'ts': time.time()}, indent=2)
        )
        for i in range(60):
            time.sleep(30)
            d.get('https://example.com')
            log.info('tick %d' % i)
    except KeyboardInterrupt:
        log.info('interrupted')
    finally:
        save_cookies(d)
        try:
            d.quit()
        except Exception:
            pass
        log.info('shutdown')


if __name__ == '__main__':
    main()
