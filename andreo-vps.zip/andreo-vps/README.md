# temp-vps-selenium

## setup
1. `git init && git add . && git commit -m init`
2. `git remote add origin <repo-url> && git push -u origin main`
3. Settings -> Secrets -> Actions:
   - `RCLONE_CONF` = full rclone.conf contents
   - `BACKUP_PASS` = strong passphrase
4. Edit `your-remote` in:
   - `.github/workflows/vps.yml`
   - `scripts/backup-daemon.sh`
   - `scripts/final-escape.sh`
5. Actions -> Run workflow.

## restore locally
```bash
export BACKUP_PASS='your-pass'
LATEST=$(rclone lsf your-remote:backups/actions/ --files-only --include 'session-*.enc' | sort | tail -1)
rclone copy "your-remote:backups/actions/$LATEST" /tmp/ --quiet
openssl enc -d -aes-256-cbc -pbkdf2 -in "/tmp/$LATEST" -out /tmp/restore.tar.gz -pass pass:"$BACKUP_PASS"
mkdir -p restored && tar -xzf /tmp/restore.tar.gz -C restored
```
